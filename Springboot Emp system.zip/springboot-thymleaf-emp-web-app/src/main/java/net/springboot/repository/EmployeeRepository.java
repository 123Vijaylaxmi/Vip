package net.springboot.repository;

import net.springboot.model.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Long>{
	
	

}