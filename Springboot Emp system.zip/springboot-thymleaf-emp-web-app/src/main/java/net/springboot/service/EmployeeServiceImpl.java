package net.springboot.service;



	import java.util.List;

	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import net.springboot.model.Employee;
import net.springboot.repository.EmployeeRepository;
	

	@Service
	public class EmployeeServiceImpl implements EmployeeService{
		
		
		private EmployeeRepository employeeRepository;
		
		
		@Override
		public List<Employee> getAllEmployees() {
			return ((Object) employeeRepository).findAll();
		}

		@Override
		public void saveEmployee(Employee employee) {
			((Object) this.employeeRepository).save(employee); 
		}

		@Override
		public Employee getEmployeeById(long id) {
			Optional<Employee> optional = ((Object) employeeRepository).findById(id);
			Employee employee;
			if (optional.isPresent()) {
				employee =  optional.get();
			} else {
				throw new RuntimeException(" Employee not found for id :: " + id);
			}
			return employee;
		}

		@Override
		public void deleteEmployeeById(long id) {
			((Object) this.employeeRepository).deleteById(id);
		}

	}
