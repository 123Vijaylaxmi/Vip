package dao;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;


@Repository 
public class EmployeeDao {
	
	@Autowired
	private EmployeeRepository employeerepository;

}
